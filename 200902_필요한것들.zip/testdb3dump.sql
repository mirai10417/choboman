-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: localhost    Database: testdb3
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board` (
  `bno` int NOT NULL,
  `bwriter` varchar(50) NOT NULL,
  `btitle` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `bcontent` varchar(4000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `bdate` timestamp NOT NULL,
  `hit` int NOT NULL DEFAULT '0',
  `ncheck` varchar(2) NOT NULL DEFAULT 'N',
  `bno_reply` int NOT NULL DEFAULT '0',
  `reply_order` int NOT NULL,
  `reply_depth` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `boardlog`
--

DROP TABLE IF EXISTS `boardlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `boardlog` (
  `bno` int NOT NULL,
  `id` varchar(50) NOT NULL DEFAULT '',
  KEY `FK__boardtest` (`bno`),
  KEY `FK__usertest` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `boardlog`
--

LOCK TABLES `boardlog` WRITE;
/*!40000 ALTER TABLE `boardlog` DISABLE KEYS */;
INSERT INTO `boardlog` VALUES (1,'test2'),(1,'test2'),(5,'test2'),(3,'test2'),(5,'test2'),(3,'test2'),(5,'test1'),(5,'test1'),(4,'test1'),(5,'test1'),(2,'test1'),(1,'test1'),(5,'test1'),(2,'test1'),(3,'test1'),(3,'test1'),(3,'test1'),(3,'test1'),(3,'test1');
/*!40000 ALTER TABLE `boardlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `boardtest`
--

DROP TABLE IF EXISTS `boardtest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `boardtest` (
  `bno` int NOT NULL,
  `bwriter` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '게시글작성자',
  `btitle` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '게시글제목',
  `bcontent` varchar(4000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '게시글내용',
  `bdate` timestamp NOT NULL COMMENT '게시글작성시간',
  `hit` int NOT NULL DEFAULT '0',
  `ncheck` varchar(2) NOT NULL DEFAULT 'N',
  `parent_bno` int DEFAULT NULL,
  `rp` int DEFAULT NULL,
  `secpw` varchar(50) DEFAULT NULL,
  `seccheck` varchar(50) NOT NULL DEFAULT 'N',
  `alarm` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'N' COMMENT '알림유형',
  `id` varchar(50) NOT NULL,
  PRIMARY KEY (`bno`),
  KEY `FK_boardtest_usertest` (`id`),
  CONSTRAINT `FK_boardtest_usertest` FOREIGN KEY (`id`) REFERENCES `usertest` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `boardtest`
--

LOCK TABLES `boardtest` WRITE;
/*!40000 ALTER TABLE `boardtest` DISABLE KEYS */;
INSERT INTO `boardtest` VALUES (1,'윤현수1','안녕','안녕','2020-09-02 08:32:14',0,'N',0,1,NULL,'N','N','test1'),(2,'윤현수1','글이 안보여','네','2020-09-02 08:36:36',0,'N',0,2,'','N','N','test1'),(3,'윤현수1','비밀글이야','안녕','2020-09-02 08:37:05',6,'N',0,3,'1234','Y','N','test1');
/*!40000 ALTER TABLE `boardtest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu` (
  `menuno` int NOT NULL,
  `menuname` varchar(50) NOT NULL,
  `menutype` varchar(50) NOT NULL DEFAULT 'B',
  `menudate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posting`
--

DROP TABLE IF EXISTS `posting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posting` (
  `pid` int NOT NULL,
  `pwriter` varchar(50) NOT NULL DEFAULT '',
  `pcontent` varchar(350) NOT NULL DEFAULT '',
  `pdate` timestamp NOT NULL,
  `pauth` varchar(50) NOT NULL DEFAULT 'N',
  `bno` int NOT NULL,
  PRIMARY KEY (`pid`),
  KEY `FK_posting_boardtest` (`bno`),
  CONSTRAINT `FK_posting_boardtest` FOREIGN KEY (`bno`) REFERENCES `boardtest` (`bno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posting`
--

LOCK TABLES `posting` WRITE;
/*!40000 ALTER TABLE `posting` DISABLE KEYS */;
/*!40000 ALTER TABLE `posting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usertest`
--

DROP TABLE IF EXISTS `usertest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usertest` (
  `id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '회원아이디',
  `pw` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '회원패스워드',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '회원이름',
  `date` date NOT NULL COMMENT '회원가입날짜',
  `auth` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'U' COMMENT '회원권한등급',
  `bwa` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'N' COMMENT '게시글작성권한',
  `ua` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'N' COMMENT '게시글업데이트권한',
  `da` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'N' COMMENT '게시글삭제권한',
  `brwa` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'N' COMMENT '게시글답글작성권한',
  `ra` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'N' COMMENT '게시글댓글작성권한',
  `baa` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'N' COMMENT '게시판진입권한',
  `ma` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'N' COMMENT '게시판관리자권한',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usertest`
--

LOCK TABLES `usertest` WRITE;
/*!40000 ALTER TABLE `usertest` DISABLE KEYS */;
INSERT INTO `usertest` VALUES ('admin','1234','관리자','2020-09-01','A','Y','Y','Y','Y','Y','Y','Y'),('computer','asd123','컴퓨터','2020-08-28','U','N','N','N','N','N','N','N'),('hometax','asd123','홈택스','2020-08-28','U','N','N','N','N','N','N','N'),('ktw1989','xodn1989','김태우','2020-08-28','U','N','N','N','N','N','N','N'),('orderby','asd123','정렬맨','2020-08-31','U','N','N','N','N','N','N','N'),('phonee','asd123','휴대폰','2020-08-28','U','N','N','N','N','N','N','N'),('test','1234','윤현수','2020-08-24','U','N','N','N','N','N','N','N'),('test1','1234','윤현수1','2020-08-24','U','N','N','N','N','N','N','N'),('test10','1234','윤현수10','2020-09-02','U','Y','Y','Y','Y','Y','Y','Y'),('test2','1234','윤현수2','2020-08-24','U','N','N','N','N','N','N','N'),('test4','1234','윤현수4','2020-09-02','U','N','N','N','N','N','N','N'),('test5','1234','윤현수5','2020-09-02','U','N','N','N','N','N','N','N'),('test6','1234','윤현수6','2020-09-01','U','N','N','N','N','N','N','N'),('test7','1234','윤현수7','2020-09-01','U','N','N','N','N','N','N','N'),('test8','1234','윤현수8','2020-09-02','U','N','N','N','N','N','N','N'),('test9','1234','윤현수9','2020-09-02','U','N','N','N','N','N','N','N');
/*!40000 ALTER TABLE `usertest` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-02 18:29:30
